SO101 current arm — consolidated physical links

Seven physical rigid links, six revolute joints (dof_1..dof_6), seven fixed named reference frames including imu_link and frame_gripperframe. Each physical link contains all meshes belonging to its rigid assembly. No fixed-joint merging is needed to combine physical CAD parts. Sensor/reference frames may still be fused by importers: preserve or recreate them as sites/frames.

All 18 visual parts, joint motion, limits, masses, COMs and inertias are preserved from the RobotStudio-properties package. Verified across 1001 configurations including limits.

Zero configuration remains the extended pose. RobotStudio angles = dof angles + [0,90,-90,0,0,0] degrees.

Mass/inertia baseline: TheRobotStudio/SO-ARM100 commit a758567c3978dfeefe282ede0500085a48fe8f78, Simulation/SO101/so101_new_calib.urdf. Modified holder/IMU additional mass remains unmeasured. No collision or actuator/sensor simulation definitions added. Onshape CAD is unchanged. Native ROS 1 launch file retained.
